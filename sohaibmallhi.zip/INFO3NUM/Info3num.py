
#Color
grey    = "\033[1;37m"
red     = "\033[1;31m"
green   = "\033[1;32m"
yellow  = "\033[1;33m"
cyan    = "\033[1;96m"
purple  = "\033[1;35m"


def main_menu():

    print(cyan +"""


        
  /$$$$$$   /$$$$$$  /$$   /$$  /$$$$$$  /$$$$$$ /$$$$$$$        /$$      /$$  /$$$$$$  /$$       /$$       /$$   /$$ /$$$$$$
 /$$__  $$ /$$__  $$| $$  | $$ /$$__  $$|_  $$_/| $$__  $$      | $$$    /$$$ /$$__  $$| $$      | $$      | $$  | $$|_  $$_/
| $$  \__/| $$  \ $$| $$  | $$| $$  \ $$  | $$  | $$  \ $$      | $$$$  /$$$$| $$  \ $$| $$      | $$      | $$  | $$  | $$  
|  $$$$$$ | $$  | $$| $$$$$$$$| $$$$$$$$  | $$  | $$$$$$$       | $$ $$/$$ $$| $$$$$$$$| $$      | $$      | $$$$$$$$  | $$  
 \____  $$| $$  | $$| $$__  $$| $$__  $$  | $$  | $$__  $$      | $$  $$$| $$| $$__  $$| $$      | $$      | $$__  $$  | $$  
 /$$  \ $$| $$  | $$| $$  | $$| $$  | $$  | $$  | $$  \ $$      | $$\  $ | $$| $$  | $$| $$      | $$      | $$  | $$  | $$  
|  $$$$$$/|  $$$$$$/| $$  | $$| $$  | $$ /$$$$$$| $$$$$$$/      | $$ \/  | $$| $$  | $$| $$$$$$$$| $$$$$$$$| $$  | $$ /$$$$$$
 \______/  \______/ |__/  |__/|__/  |__/|______/|_______/       |__/     |__/|__/  |__/|________/|________/|__/  |__/|______/
                                                                                                                             
                                                                                                                             
                                                                                                                             

                                                                """)
    print("")
    print(yellow + """
                                    Available Scripts 

                                <a> Network Enumeration 
                                <b> Web Enumeration
                                <c> Open Source Intelligence (OSINT)
                                
                                <i> info
                                <x> Hint

    """)

    info3num()

def info3num():
    from NetworkEnum import networkenum
    from WebEnum import webenum
    from CryptoHash import cryptohash
    from Osint import osint

    inp = (input(cyan + "Choose >> "))
    if (inp == 'a'):
        networkenum()
    elif (inp == 'b'):
        webenum()
    elif (inp == 'c'):
        osint()
    elif (inp == 'd'):
        cryptohash()
    elif (inp == 'exit'):
        exit()
    elif (inp == 'i'):
        print(green +"""
        
            |>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>|
            |*                                                                                          *|
            |*    Created By      : M SOHAIB MALLHI                                                     *|
            |*    LinkedIn        : https://www.linkedin.com/in/ihllambiahos                            *|                                                                            
            |*    Project Name    : INFO3NUM | Infomation Enumeration Tool                              *|
            |*    Created Date    : 18.02.2024                                                          *|
            |*    Domain          : Cyberelynetsolutions.com                                            *|
            |*    Use             : Used to enumerate the active host/website for Penteration Testing   *|
            |*                                                                                          *|
            |<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<|  
        
        
        """)
    elif (inp == 'x'):
        print(red + "Hint :")
        print(green + "ls " + grey + "  - to list scripts.")
        print(green + "back " + grey + "  - previous modules.")
        print(green + "exit " + grey + "- to exit the tool.")
    elif (inp == 'ls'):
        print(green + """
                                    Tools available 

                                <a> Network Enumeration 
                                <b> Web Enumeration
                                <c> Open Source Intelligence (OSINT)
                                
                                <i> info
                                <x> Hint
             
            """)
    else:
        print(red + "Enter an valid option")

    while True:
        info3num()
    


if __name__ == "__main__":
    main_menu()
